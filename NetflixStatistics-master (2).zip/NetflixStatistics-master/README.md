# NetflixStatistics
Programmeren2 opdracht

In de map SQL Database staat alles in over hoe je de database importeert en alle bijbehorende ontwerpen.
